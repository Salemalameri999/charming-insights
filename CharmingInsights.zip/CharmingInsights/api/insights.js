import fetch from "node-fetch";

export default async function handler(req, res) {
    const id = req.query.id;
    if (!id) return res.status(400).json({ error: "Missing id" });

    // Try to convert placeId → universeId
    let universeId = id;
    try {
        const mapRes = await fetch(
            `https://apis.roblox.com/universes/v1/places/${id}/universe`
        );
        const mapJson = await mapRes.json();
        if (mapJson.universeId) {
            universeId = mapJson.universeId;
        }
    } catch (e) {}

    // Fetch real game stats
    const gameRes = await fetch(
        `https://games.roblox.com/v1/games?universeIds=${universeId}`
    );
    const gameJson = await gameRes.json();

    if (!gameJson || !gameJson.data || !gameJson.data[0]) {
        return res.status(404).json({ error: "Game not found" });
    }

    const g = gameJson.data[0];

    return res.status(200).json({
        name: g.name,
        visits: g.visits,
        playing: g.playing,
        likes: g.likeCount,
        dislikes: g.dislikeCount,
        favorites: g.favoritedCount,
        created: g.created,
        updated: g.updated
    });
}
